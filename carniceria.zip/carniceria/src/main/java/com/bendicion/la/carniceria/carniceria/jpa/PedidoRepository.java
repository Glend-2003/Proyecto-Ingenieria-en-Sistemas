package com.bendicion.la.carniceria.carniceria.jpa;

/**
 *
 * @author Jamel Sandí
 */


public interface PedidoRepository {
    
}
