package com.bendicion.la.carniceria.carniceria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarniceriaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarniceriaApplication.class, args);
	}

}
