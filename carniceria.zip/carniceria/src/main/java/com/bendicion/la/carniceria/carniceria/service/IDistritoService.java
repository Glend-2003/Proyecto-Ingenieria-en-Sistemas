package com.bendicion.la.carniceria.carniceria.service;
import com.bendicion.la.carniceria.carniceria.domain.Distrito;
import java.util.List;

/**
 *
 * @author Jamel Sandí
 */

public interface IDistritoService {
    
    public List<Distrito> getDistrito();
}
