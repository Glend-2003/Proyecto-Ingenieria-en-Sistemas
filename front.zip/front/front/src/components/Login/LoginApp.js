import React, { useState } from 'react';
import axios from 'axios';

function LoginApp() {
    const [loginData, setLoginData] = useState({
        correoUsuario: '',
        contrasenaUsuario: ''
    });
    const [loginStatus, setLoginStatus] = useState('');

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setLoginData({
            ...loginData,
            [name]: value
        });
    };

    const login = () => {
        axios.post('http://localhost:8080/usuario/login', loginData)
            .then(response => {
                // Verificar si se recibe el correo del usuario
                if (response.data.correoUsuario) {
                    setLoginStatus("Login exitoso. Bienvenido " + response.data.nombreUsuario);
                    window.location.href = '/principal'; // Redirigir a la página principal
                } else {
                    setLoginStatus("Credenciales incorrectas");
                }
            })
            .catch(error => {
                console.error('Error en el login:', error.response ? error.response.data : error.message);
                setLoginStatus("Error en el servidor o en las credenciales");
            });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        login(); // Llamar a la función login al hacer submit
    };

    return (
        <div>
            <h2>Iniciar sesión</h2>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Correo:</label>
                    <input
                        type="email"
                        name="correoUsuario"
                        value={loginData.correoUsuario}
                        onChange={handleInputChange}
                        required
                    />
                </div>
                <div>
                    <label>Contraseña:</label>
                    <input
                        type="password"
                        name="contrasenaUsuario"
                        value={loginData.contrasenaUsuario}
                        onChange={handleInputChange}
                        required
                    />
                </div>
                <button type="submit">Iniciar sesión</button>
            </form>
            <p>{loginStatus}</p>
        </div>
    );
}

export default LoginApp;
