import React, { useState, useEffect } from 'react';

const LoginForm = ({ loginData, setLoginData, login }) => {
    const [form, setForm] = useState({
        correoUsuario: '',
        contraseniaUsuario: '',
    });

    useEffect(() => {
        if (loginData) {
            setForm(loginData);
        }
    }, [loginData]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setForm({
            ...form,
            [name]: value,
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        // Validaciones simples
        if (!form.correoUsuario || !form.contraseniaUsuario) {
            console.log('Por favor, rellene todos los campos');
            return;
        }

        // Llama a la función login con los datos ingresados
        login(form);
        // Limpiar el formulario
        setForm({
            correoUsuario: '',
            contraseniaUsuario: '',
        });
    };

    return (
        <div>
            <h1>Login</h1>
            <form onSubmit={handleSubmit}>
                <input
                    type="text"
                    name="correoUsuario"
                    placeholder="Correo"
                    value={form.correoUsuario}
                    onChange={handleChange}
                />
                <input
                    type="password"
                    name="contraseniaUsuario"
                    placeholder="Contraseña"
                    value={form.contraseniaUsuario}
                    onChange={handleChange}
                />
                <button type="submit">Login</button>
            </form>
        </div>
    );
};

export default LoginForm;
