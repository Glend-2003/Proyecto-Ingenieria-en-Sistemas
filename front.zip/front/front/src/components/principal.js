import React from 'react';

const Principal = () => {
    return (
        <div>
            <h1>Bienvenido a la página principal</h1>
            <nav>
                <ul>
                    <li>
                        <a href="/registrarse">Registrarse</a>
                    </li>
                    <li>
                        <a href="/registrar">Registrar</a>
                    </li>
                </ul>
            </nav>
        </div>
    );
};

export default Principal;
